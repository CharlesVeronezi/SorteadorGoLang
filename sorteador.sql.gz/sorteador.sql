-- Adminer 4.8.1 PostgreSQL 16.3 dump

DROP TABLE IF EXISTS "cupons";
DROP SEQUENCE IF EXISTS cupons_id_cupons_seq;
CREATE SEQUENCE cupons_id_cupons_seq INCREMENT 1 MINVALUE 1 MAXVALUE 2147483647 CACHE 1;

CREATE TABLE "public"."cupons" (
    "id_cupons" integer DEFAULT nextval('cupons_id_cupons_seq') NOT NULL,
    "codigo_cupom" character varying NOT NULL,
    "id_usuario" integer,
    "id_sorteio" integer,
    CONSTRAINT "cupons_pkey" PRIMARY KEY ("id_cupons")
) WITH (oids = false);

INSERT INTO "cupons" ("id_cupons", "codigo_cupom", "id_usuario", "id_sorteio") VALUES
(1,	'329462698930006143319861804403156581933',	1,	1),
(2,	'306197818612553404933194897947208322603',	1,	1),
(3,	'279506711239606057524547513248105912647',	1,	1),
(4,	'309492413448090928580351029904693724371',	2,	1),
(5,	'329660915924129914107781865995682785967',	2,	1),
(6,	'319317350363213461087684162893957200201',	2,	1),
(7,	'284899137950287168152150683156283294641',	3,	1);

DROP TABLE IF EXISTS "sorteio";
DROP SEQUENCE IF EXISTS sorteio_id_sorteio_seq;
CREATE SEQUENCE sorteio_id_sorteio_seq INCREMENT 1 MINVALUE 1 MAXVALUE 2147483647 CACHE 1;

CREATE TABLE "public"."sorteio" (
    "id_sorteio" integer DEFAULT nextval('sorteio_id_sorteio_seq') NOT NULL,
    "nome_sorteio" character varying(500) NOT NULL,
    "data_sorteio" date NOT NULL,
    CONSTRAINT "sorteio_pkey" PRIMARY KEY ("id_sorteio")
) WITH (oids = false);


DROP TABLE IF EXISTS "usuario";
DROP SEQUENCE IF EXISTS usuario_id_usuario_seq;
CREATE SEQUENCE usuario_id_usuario_seq INCREMENT 1 MINVALUE 1 MAXVALUE 2147483647 CACHE 1;

CREATE TABLE "public"."usuario" (
    "id_usuario" integer DEFAULT nextval('usuario_id_usuario_seq') NOT NULL,
    "nome_usuario" character varying(200),
    "data_criacao_usuario" date NOT NULL,
    CONSTRAINT "usuario_pkey" PRIMARY KEY ("id_usuario")
) WITH (oids = false);


-- 2024-06-12 20:15:25.192908+00
